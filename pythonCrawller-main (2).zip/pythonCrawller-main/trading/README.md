# Trading Dashboard

A web-based trading dashboard with multiple strategy support.

## Getting Started with CloudShell

1. Open CloudShell from the GCP Console
2. Clone the repository:
```bash
git clone https://github.com/your-username/trading-dashboard.git
```

3. Navigate to the project directory:
```bash
cd trading-dashboard
```

4. Install dependencies:
```bash
npm install
```

5. Configure environment variables:
```bash
cp .env.example .env
# Edit .env with your API keys
```

6. Start the development server:
```bash
npm run dev
```

7. Access the application at http://localhost:8080

## Deploying to Google App Engine

1. Configure your project:
```bash
gcloud config set project YOUR_PROJECT_ID
gcloud config set run/region us-central1
```

2. Deploy the application:
```bash
gcloud app deploy
```

3. Access your deployed application:
```bash
gcloud app browse
```

## Project Structure

- `/js` - JavaScript source files
- `/css` - Stylesheets
- `/public` - Static assets
- `app.yaml` - App Engine configuration
- `cloudbuild.yaml` - Cloud Build configuration
- `package.json` - Node.js dependencies
