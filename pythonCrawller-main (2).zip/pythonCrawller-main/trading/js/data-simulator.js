// js/data-simulator.js
import { updatePortfolioChart } from './charts.js';
import { computeSignal } from './trading-logic.js';

let valueHistory = [];

export function startSimulation(interval = 1000) {
  setInterval(() => {
    const last = valueHistory.length ? valueHistory[valueHistory.length - 1] : 10000;
    const change = (Math.random() - 0.5) * 200;
    const newValue = Math.max(0, last + change);
    const ts = Date.now();
    valueHistory.push(newValue);
    updatePortfolioChart(ts, newValue);
    const signal = computeSignal(valueHistory, newValue);
    if (signal) showSignal(signal, ts);
  }, interval);
}

function showSignal(signal, ts) {
  const panel = document.getElementById('signal-panel');
  const el = document.createElement('div');
  el.className = `signal ${signal.toLowerCase()}`;
  el.innerText = `${signal} @ ${new Date(ts).toLocaleTimeString()}`;
  panel.prepend(el);
  setTimeout(() => el.remove(), 5000);
}