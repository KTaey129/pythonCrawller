import { initCharts } from './charts.js';
import { startSimulation } from './data-simulator.js';
import { BybitAPI } from './bybit-api.js';
import { MultiCharts } from './multi-charts.js';

// Bybit API configuration
const BYBIT_CONFIG = {
    apiKey: 'YOUR_API_KEY',
    secret: 'YOUR_SECRET',
    useTestnet: true // Set to false for live trading
};

// Initialize Bybit API
const bybit = new BybitAPI(BYBIT_CONFIG.apiKey, BYBIT_CONFIG.secret, BYBIT_CONFIG.useTestnet);

// Trading configuration
const TRADING_CONFIG = {
    symbol: 'BTCUSD',
    riskPerTrade: 0.01, // 1% risk per trade
    positionSize: 0.01, // 0.01 BTC
    interval: '1m' // 1-minute candles
};

// Global state
let currentPrice = null;
let position = null;
let lastSignal = null;

// Update UI with trading info
function updateTradingInfo() {
    const infoPanel = document.getElementById('trading-info');
    if (!infoPanel) return;

    infoPanel.innerHTML = `
        <div>Current Price: ${currentPrice || 'N/A'}</div>
        <div>Position: ${position ? position.side : 'None'}</div>
        <div>Last Signal: ${lastSignal || 'None'}</div>
    `;
}

document.addEventListener('DOMContentLoaded', async () => {
    // Initialize strategy selector
    const strategySelect = document.getElementById('strategy-select');
    let currentStrategy = null;

    // Strategy selection handler
    strategySelect.addEventListener('change', (e) => {
        const selectedStrategy = e.target.value;
        console.log('Selected strategy:', selectedStrategy);
        
        // Update UI and apply strategy
        updateTradingInfo();
        applyStrategy(selectedStrategy);
    });

    // Function to apply selected strategy
    function applyStrategy(strategy) {
        // Initialize appropriate strategy based on selection
        switch(strategy) {
            case 'rsi':
                currentStrategy = new TradingStrategy();
                break;
            case 'ma':
                currentStrategy = new MovingAverageStrategy();
                break;
            case 'macd':
                currentStrategy = new MACDStrategy();
                break;
            case 'custom':
                currentStrategy = new CustomStrategy();
                break;
            default:
                currentStrategy = new TradingStrategy();
        }
        
        // Update UI with strategy settings
        updateStrategySettings();
    }

    // Function to update strategy settings UI
    function updateStrategySettings() {
        const settingsPanel = document.getElementById('strategy-settings');
        if (settingsPanel) {
            settingsPanel.innerHTML = '';
            
            if (currentStrategy) {
                // Add strategy-specific settings
                const settings = currentStrategy.getSettings();
                Object.entries(settings).forEach(([key, value]) => {
                    const setting = document.createElement('div');
                    setting.className = 'strategy-setting';
                    setting.innerHTML = `
                        <label>${key}:</label>
                        <input type="number" value="${value}" 
                               data-setting="${key}" 
                               onchange="handleSettingChange(this)">
                    `;
                    settingsPanel.appendChild(setting);
                });
            }
        }
    }

    // Function to handle strategy setting changes
    function handleSettingChange(input) {
        const settingName = input.dataset.setting;
        const newValue = parseFloat(input.value);
        
        if (currentStrategy) {
            currentStrategy.updateSetting(settingName, newValue);
        }
    }
    initCharts();
    startSimulation();

    // Initialize multi-charts
    let multiCharts = null;
    let selectedCoins = new Set(['BTCUSD', 'ETHUSD', 'SOLUSD', 'XRPUSD']);

    // Get all available coin pairs from Bybit
    const coinPairs = await bybit.getCoinPairs();

    // Toggle charts button
    const toggleChartsBtn = document.getElementById('toggle-charts');
    toggleChartsBtn.addEventListener('click', () => {
        const chartsSection = document.getElementById('charts-section');
        if (!multiCharts) {
            multiCharts = new MultiCharts(bybit, Array.from(selectedCoins));
            chartsSection.style.display = 'grid';
        } else {
            chartsSection.style.display = 'none';
            multiCharts = null;
        }
    });

    // Coin search functionality
    const coinSearchBox = document.getElementById('coin-search');
    const resultsContainer = document.getElementById('coin-results');

    coinSearchBox.addEventListener('input', async (e) => {
        const searchTerm = e.target.value.toLowerCase();
        resultsContainer.innerHTML = '';
        resultsContainer.classList.add('visible');

        // Filter coin pairs based on search
        const filteredPairs = coinPairs.filter(pair => 
            pair.symbol.toLowerCase().includes(searchTerm) || 
            pair.name.toLowerCase().includes(searchTerm)
        );

        // Display results
        filteredPairs.forEach(pair => {
            const resultItem = document.createElement('div');
            resultItem.className = 'coin-item';
            resultItem.textContent = `${pair.name} (${pair.symbol})`;
            if (selectedCoins.has(pair.symbol)) {
                resultItem.classList.add('selected');
            }
            
            resultItem.addEventListener('click', () => {
                if (selectedCoins.has(pair.symbol)) {
                    selectedCoins.delete(pair.symbol);
                    resultItem.classList.remove('selected');
                } else {
                    selectedCoins.add(pair.symbol);
                    resultItem.classList.add('selected');
                }
                
                // Update charts if they're visible
                if (multiCharts) {
                    multiCharts.setChartCount(selectedCoins.size);
                    multiCharts.setSymbols(Array.from(selectedCoins));
                }
            });

            resultsContainer.appendChild(resultItem);
        });

        // Hide results if no matches
        if (filteredPairs.length === 0) {
            resultsContainer.classList.remove('visible');
        }
    });

    // Hide results when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.chart-search')) {
            resultsContainer.classList.remove('visible');
        }
    });

    // Handle Enter key
    searchBox.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            resultsContainer.classList.remove('visible');
        }
    });

    // Add coin pairs to config
    config.coinPairs = coinPairs.map(pair => ({
        symbol: pair.symbol,
        name: pair.name,
        enabled: selectedCoins.has(pair.symbol)
    }));

    // Chart count controls
    const decreaseBtn = document.getElementById('decrease-charts');
    const increaseBtn = document.getElementById('increase-charts');
    const chartCountSpan = document.getElementById('chart-count');

    decreaseBtn.addEventListener('click', () => {
        if (multiCharts) {
            const count = parseInt(chartCountSpan.textContent);
            if (count > 1) {
                multiCharts.setChartCount(count - 1);
                chartCountSpan.textContent = count - 1;
            }
        }
    });

    increaseBtn.addEventListener('click', () => {
        if (multiCharts) {
            const count = parseInt(chartCountSpan.textContent);
            multiCharts.setChartCount(count + 1);
            chartCountSpan.textContent = count + 1;
        }
    });

    // Timeframe selector
    const timeframeSelector = document.getElementById('timeframe-selector');
    timeframeSelector.addEventListener('change', () => {
        if (multiCharts) {
            multiCharts.setTimeframe(timeframeSelector.value);
        }
    });

    // Start updating charts every 30 seconds
    setInterval(async () => {
        try {
            if (multiCharts) {
                await multiCharts.updateCharts();
            }
        } catch (error) {
            console.error('Error updating charts:', error);
        }
    }, 30000); // Update every 30 seconds

    // Initial chart update if charts are shown
    if (multiCharts) {
        await multiCharts.updateCharts();
    }

    // Search filter
    const searchBox = document.querySelector('.search-box');
    searchBox.addEventListener('input', () => {
        const filter = searchBox.value.toLowerCase();
        document.querySelectorAll('.table-row').forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
        });
    });

    // Time filter buttons (stub)
    document.querySelectorAll('.time-filter').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelector('.time-filter.active').classList.remove('active');
            btn.classList.add('active');
            // TODO: handle timeframe change
        });
    });
});