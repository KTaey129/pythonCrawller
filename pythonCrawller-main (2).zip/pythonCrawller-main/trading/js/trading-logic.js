// js/trading-logic.js
const RSI_PERIOD = 14;
const MA_FAST = 10;
const MA_SLOW = 30;
const RSI_OVERBOUGHT = 70;
const RSI_OVERSOLD = 30;

export class TradingStrategy {
    constructor() {
        this.position = null;
        this.entryPrice = null;
        this.stopLoss = null;
        this.takeProfit = null;
        this.rsiValues = [];
        this.priceHistory = [];
    }

    // Calculate RSI
    calculateRSI(prices) {
        if (prices.length < RSI_PERIOD) return null;
        
        const gains = [];
        const losses = [];
        
        for (let i = 1; i < prices.length; i++) {
            const change = prices[i] - prices[i - 1];
            if (change > 0) gains.push(change);
            else losses.push(Math.abs(change));
        }
        
        const avgGain = gains.reduce((a, b) => a + b) / gains.length;
        const avgLoss = losses.reduce((a, b) => a + b) / losses.length;
        
        const rs = avgGain / avgLoss;
        return 100 - (100 / (1 + rs));
    }

    // Calculate Moving Averages
    calculateMA(prices, period) {
        if (prices.length < period) return null;
        return prices.slice(-period).reduce((a, b) => a + b) / period;
    }

    // Calculate position size based on volatility
    calculatePositionSize(price, volatility) {
        // Simple risk management: 1% of portfolio per trade
        // Adjust based on volatility
        return 0.01 / volatility;
    }

    // Generate trading signal
    generateSignal(price, volatility) {
        this.priceHistory.push(price);
        
        // Calculate indicators
        const rsi = this.calculateRSI(this.priceHistory);
        const fastMA = this.calculateMA(this.priceHistory, MA_FAST);
        const slowMA = this.calculateMA(this.priceHistory, MA_SLOW);
        
        // Basic trend following with MA crossover
        const trend = fastMA > slowMA;
        
        // RSI conditions
        const isOverbought = rsi > RSI_OVERBOUGHT;
        const isOversold = rsi < RSI_OVERSOLD;
        
        // Position sizing
        const positionSize = this.calculatePositionSize(price, volatility);
        
        // Generate signal based on conditions
        let signal = null;
        
        if (!this.position) {
            // Entry conditions
            if (trend && isOversold) {
                signal = {
                    type: 'BUY',
                    size: positionSize,
                    entryPrice: price,
                    stopLoss: price * 0.98, // 2% stop loss
                    takeProfit: price * 1.02  // 2% take profit
                };
            } else if (!trend && isOverbought) {
                signal = {
                    type: 'SELL',
                    size: positionSize,
                    entryPrice: price,
                    stopLoss: price * 1.02,
                    takeProfit: price * 0.98
                };
            }
        } else {
            // Exit conditions
            if (this.position.type === 'BUY' && 
                (price <= this.position.stopLoss || price >= this.position.takeProfit)) {
                signal = { type: 'EXIT' };
            } else if (this.position.type === 'SELL' && 
                (price >= this.position.stopLoss || price <= this.position.takeProfit)) {
                signal = { type: 'EXIT' };
            }
        }
        
        // Update position if signal generated
        if (signal) {
            if (signal.type === 'EXIT') {
                this.position = null;
            } else {
                this.position = signal;
            }
        }
        
        return signal;
    }

    // Update position
    updatePosition(price) {
        if (this.position) {
            const pnl = this.position.type === 'BUY' 
                ? (price - this.position.entryPrice) * this.position.size
                : (this.position.entryPrice - price) * this.position.size;
            
            return {
                pnl,
                position: this.position,
                currentPrice: price
            };
        }
        return null;
    }
}

export function computeSignal(history, newValue) {
    const strategy = new TradingStrategy();
    const volatility = calculateVolatility(history);
    return strategy.generateSignal(newValue, volatility);
}

// Helper function to calculate volatility
function calculateVolatility(prices) {
    if (prices.length < 2) return 0;
    
    const avg = prices.reduce((a, b) => a + b) / prices.length;
    const squaredDiffs = prices.map(price => Math.pow(price - avg, 2));
    const variance = squaredDiffs.reduce((a, b) => a + b) / prices.length;
    return Math.sqrt(variance);
}