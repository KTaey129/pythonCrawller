let portfolioChart, startAllocationChart, endAllocationChart;

export function initCharts() {
  const ctx1 = document.getElementById('portfolioChart').getContext('2d');
  portfolioChart = new Chart(ctx1, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{
        label: 'Portfolio Value',
        data: [],
        borderColor: '#4f46e5',
        backgroundColor: 'rgba(79,70,229,0.2)',
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      scales: {
        x: { display: true },
        y: { beginAtZero: false }
      }
    }
  });

  const ctx2 = document.getElementById('startAllocationChart').getContext('2d');
  startAllocationChart = new Chart(ctx2, {
    type: 'doughnut',
    data: {
      labels: ['To supply', 'Collateral', 'Debt'],
      datasets: [{
        data: [83, 15, 2],
        backgroundColor: ['#00d4aa', '#ff6b6b', '#4f46e5']
      }]
    },
    options: { responsive: true, plugins: { legend: { display: false } } }
  });

  const ctx3 = document.getElementById('endAllocationChart').getContext('2d');
  endAllocationChart = new Chart(ctx3, {
    type: 'doughnut',
    data: {
      labels: ['To supply', 'Collateral', 'Debt'],
      datasets: [{
        data: [80, 18, 2],
        backgroundColor: ['#00d4aa', '#ff6b6b', '#4f46e5']
      }]
    },
    options: { responsive: true, plugins: { legend: { display: false } } }
  });
}

export function updatePortfolioChart(timestamp, value) {
  const timeLabel = new Date(timestamp).toLocaleTimeString();
  portfolioChart.data.labels.push(timeLabel);
  portfolioChart.data.datasets[0].data.push(value);
  if (portfolioChart.data.labels.length > 20) {
    portfolioChart.data.labels.shift();
    portfolioChart.data.datasets[0].data.shift();
  }
  portfolioChart.update();
}