// js/config.js
import dotenv from 'dotenv';

dotenv.config();

// Validate required environment variables
const requiredEnvVars = ['BYBIT_API_KEY', 'BYBIT_API_SECRET'];
const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);

if (missingVars.length > 0) {
    throw new Error(`Missing required environment variables: ${missingVars.join(', ')}`);
}

// Configuration validation
const validateConfig = (config) => {
    if (!config.bybit.apiKey || !config.bybit.secret) {
        throw new Error('Invalid API configuration');
    }
    if (config.updateInterval < 1000) {
        console.warn('Update interval is less than 1 second, which may cause performance issues');
    }
};

// Configuration object
export const API_CONFIG = {
    bybit: {
        apiKey: process.env.BYBIT_API_KEY,
        secret: process.env.BYBIT_API_SECRET,
        useTestnet: process.env.BYBIT_USE_TESTNET === 'true',
    },
    updateInterval: parseInt(process.env.UPDATE_INTERVAL || 1000),
    
    // Coin pairs configuration
    coinPairs: [
        { symbol: 'BTCUSD', name: 'Bitcoin', enabled: true },
        { symbol: 'ETHUSD', name: 'Ethereum', enabled: true },
        { symbol: 'SOLUSD', name: 'Solana', enabled: true },
        { symbol: 'XRPUSD', name: 'Ripple', enabled: true },
        { symbol: 'ADAUSD', name: 'Cardano', enabled: true },
        { symbol: 'DOTUSD', name: 'Polkadot', enabled: true },
        { symbol: 'LINKUSD', name: 'Chainlink', enabled: true },
        { symbol: 'AVAXUSD', name: 'Avalanche', enabled: true },
        { symbol: 'UNIUSD', name: 'Uniswap', enabled: true },
        { symbol: 'MATICUSD', name: 'Polygon', enabled: true }
    ]
};

// Validate configuration
validateConfig(API_CONFIG);

// Export a function to get a copy of the config
export const getConfig = () => ({
    ...API_CONFIG,
    bybit: {
        ...API_CONFIG.bybit,
        apiKey: '***', // Mask API key in exposed config
        secret: '***'  // Mask secret in exposed config
    }
});

// Export a function to get specific config values
export const getSafeConfig = (key) => {
    const config = getConfig();
    return key ? config[key] : config;
};;

// Export configuration for easy access
export default API_CONFIG;
