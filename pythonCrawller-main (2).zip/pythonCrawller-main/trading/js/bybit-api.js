// js/bybit-api.js
import axios from 'axios';

const BYBIT_API = 'https://api.bybit.com';
const TESTNET_API = 'https://api-testnet.bybit.com';

export class BybitAPI {
    constructor(apiKey, secret, useTestnet = false) {
        this.apiKey = apiKey;
        this.secret = secret;
        this.apiBase = useTestnet ? TESTNET_API : BYBIT_API;
        this.client = axios.create({
            baseURL: this.apiBase,
            headers: {
                'Content-Type': 'application/json'
            }
        });
    }

    // Get all available coin pairs
    async getCoinPairs() {
        try {
            const response = await this.client.get('/v2/public/symbols');
            return response.data.result.map(symbol => ({
                symbol: symbol.name,
                name: symbol.name.replace(/USD$/, ''),
                base_currency: symbol.base_currency,
                quote_currency: symbol.quote_currency,
                status: symbol.status
            }));
        } catch (error) {
            console.error('Error getting coin pairs:', error);
            throw error;
        }
    }

    // Get current price
    async getCurrentPrice(symbol) {
        try {
            const response = await this.client.get('/v2/public/tickers', {
                params: { symbol }
            });
            return response.data.result[0].last_price;
        } catch (error) {
            console.error('Error getting price:', error);
            throw error;
        }
    }

    // Get historical data
    async getHistoricalData(symbol, interval = '1m', limit = 200) {
        try {
            const response = await this.client.get('/v2/public/kline/list', {
                params: {
                    symbol,
                    interval,
                    limit
                }
            });
            return response.data.result;
        } catch (error) {
            console.error('Error getting historical data:', error);
            throw error;
        }
    }

    // Place order
    async placeOrder(symbol, side, type, quantity, price = null) {
        try {
            const timestamp = Date.now();
            const params = {
                api_key: this.apiKey,
                symbol,
                side,
                order_type: type,
                qty: quantity,
                timestamp,
                recv_window: 5000
            };

            if (price) {
                params.price = price;
            }

            // Sign the request
            const queryString = new URLSearchParams(params).toString();
            const signature = this.sign(queryString);
            params.sign = signature;

            const response = await this.client.post('/v2/private/order/create', params);
            return response.data.result;
        } catch (error) {
            console.error('Error placing order:', error);
            throw error;
        }
    }

    // Cancel order
    async cancelOrder(symbol, orderId) {
        try {
            const timestamp = Date.now();
            const params = {
                api_key: this.apiKey,
                symbol,
                order_id: orderId,
                timestamp,
                recv_window: 5000
            };

            const queryString = new URLSearchParams(params).toString();
            const signature = this.sign(queryString);
            params.sign = signature;

            const response = await this.client.post('/v2/private/order/cancel', params);
            return response.data.result;
        } catch (error) {
            console.error('Error canceling order:', error);
            throw error;
        }
    }

    // Get position
    async getPosition(symbol) {
        try {
            const timestamp = Date.now();
            const params = {
                api_key: this.apiKey,
                symbol,
                timestamp,
                recv_window: 5000
            };

            const queryString = new URLSearchParams(params).toString();
            const signature = this.sign(queryString);
            params.sign = signature;

            const response = await this.client.get('/v2/private/position/list', { params });
            return response.data.result;
        } catch (error) {
            console.error('Error getting position:', error);
            throw error;
        }
    }

    // Sign the request
    sign(queryString) {
        return crypto.createHmac('sha256', this.secret)
            .update(queryString)
            .digest('hex');
    }
}

// Export axios for direct use if needed
export { axios };
