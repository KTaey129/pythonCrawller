// js/multi-charts.js
import { BybitAPI } from './bybit-api.js';

export class MultiCharts {
    constructor(api, symbols = ['BTCUSD', 'ETHUSD', 'SOLUSD', 'XRPUSD']) {
        this.api = api;
        this.symbols = symbols;
        this.charts = {};
        this.priceHistory = {};
        this.timeframe = '1m';
        this.chartCount = symbols.length;
        this.coinOptions = [
            { symbol: 'BTCUSD', name: 'Bitcoin' },
            { symbol: 'ETHUSD', name: 'Ethereum' },
            { symbol: 'SOLUSD', name: 'Solana' },
            { symbol: 'XRPUSD', name: 'Ripple' },
            { symbol: 'ADAUSD', name: 'Cardano' },
            { symbol: 'DOTUSD', name: 'Polkadot' },
            { symbol: 'LINKUSD', name: 'Chainlink' },
            { symbol: 'AVAXUSD', name: 'Avalanche' },
            { symbol: 'UNIUSD', name: 'Uniswap' },
            { symbol: 'MATICUSD', name: 'Polygon' }
        ];
        this.initCharts();
    }

    // Initialize charts with coin selectors
    initCharts() {
        const chartSection = document.getElementById('charts-section');
        
        // Clear existing charts
        chartSection.innerHTML = '';
        
        for (let i = 0; i < this.chartCount; i++) {
            const chartContainer = document.createElement('div');
            chartContainer.className = 'chart-container';
            chartContainer.id = `chart-container-${i}`;
            
            const chartTitle = document.createElement('h3');
            const coinSelector = document.createElement('select');
            coinSelector.className = 'coin-selector';
            
            // Populate coin selector
            this.coinOptions.forEach(option => {
                const opt = document.createElement('option');
                opt.value = option.symbol;
                opt.textContent = option.name;
                if (this.symbols[i] === option.symbol) {
                    opt.selected = true;
                }
                coinSelector.appendChild(opt);
            });
            
            chartTitle.appendChild(coinSelector);
            
            const canvas = document.createElement('canvas');
            canvas.id = `chart-${i}`;
            
            chartContainer.appendChild(chartTitle);
            chartContainer.appendChild(canvas);
            chartSection.appendChild(chartContainer);
            
            // Initialize Chart.js
            this.charts[i] = new Chart(canvas, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: this.symbols[i],
                        data: [],
                        borderColor: this.getRandomColor(),
                        backgroundColor: 'rgba(79,70,229,0.2)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        x: { display: true },
                        y: { beginAtZero: false }
                    },
                    plugins: {
                        legend: { display: false }
                    }
                }
            });
            
            // Add coin change handler
            coinSelector.addEventListener('change', () => {
                this.symbols[i] = coinSelector.value;
                this.updateChart(i);
            });
        }
    }

    // Update all charts
    async updateCharts() {
        for (let i = 0; i < this.chartCount; i++) {
            try {
                const symbol = this.symbols[i];
                const data = await this.api.getHistoricalData(symbol, this.timeframe, 100);
                this.updateChart(i, data);
            } catch (error) {
                console.error(`Error updating chart ${i}:`, error);
            }
        }
    }

    // Update a single chart
    updateChart(index, data = null) {
        const chart = this.charts[index];
        if (!chart) return;

        if (!data) {
            // If no data provided, get from history
            data = this.priceHistory[this.symbols[index]] || [];
        }

        // Extract timestamps and prices
        const timestamps = data.map(d => new Date(d.open_time * 1000).toLocaleTimeString());
        const prices = data.map(d => parseFloat(d.close));

        // Update chart data
        chart.data.labels = timestamps;
        chart.data.datasets[0].data = prices;
        chart.update();

        // Update price history
        this.priceHistory[this.symbols[index]] = data;
    }

    // Change timeframe
    setTimeframe(timeframe) {
        this.timeframe = timeframe;
        this.updateCharts();
    }

    // Add or remove charts
    setChartCount(count) {
        if (count < 1) return;
        this.chartCount = count;
        this.initCharts();
    }

    // Get random color for chart lines
    getRandomColor() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    // Initialize charts for all symbols
    initCharts() {
        this.symbols.forEach(symbol => {
            const chartContainer = document.createElement('div');
            chartContainer.className = 'chart-container';
            chartContainer.id = `${symbol.toLowerCase()}-chart-container`;
            
            const chartTitle = document.createElement('h3');
            chartTitle.textContent = symbol;
            chartContainer.appendChild(chartTitle);
            
            const canvas = document.createElement('canvas');
            canvas.id = `${symbol.toLowerCase()}-chart`;
            chartContainer.appendChild(canvas);
            
            document.querySelector('.charts-section').appendChild(chartContainer);
            
            // Initialize Chart.js for this symbol
            this.charts[symbol] = new Chart(canvas, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: symbol,
                        data: [],
                        borderColor: this.getRandomColor(),
                        backgroundColor: 'rgba(79,70,229,0.2)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        x: { display: true },
                        y: { beginAtZero: false }
                    },
                    plugins: {
                        legend: { display: false }
                    }
                }
            });
        });
    }

    // Update all charts
    async updateCharts() {
        const promises = this.symbols.map(async (symbol) => {
            try {
                const data = await this.api.getHistoricalData(symbol, '1m', 100);
                this.updateChart(symbol, data);
            } catch (error) {
                console.error(`Error updating ${symbol} chart:`, error);
            }
        });
        await Promise.all(promises);
    }

    // Update a single chart
    updateChart(symbol, data) {
        const chart = this.charts[symbol];
        if (!chart) return;

        // Extract timestamps and prices
        const timestamps = data.map(d => new Date(d.open_time * 1000).toLocaleTimeString());
        const prices = data.map(d => parseFloat(d.close));

        // Update chart data
        chart.data.labels = timestamps;
        chart.data.datasets[0].data = prices;
        chart.update();

        // Update price history for trading signals
        this.priceHistory[symbol] = prices;
    }

    // Get random color for chart lines
    getRandomColor() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    // Get current prices for all symbols
    async getCurrentPrices() {
        const prices = {};
        const promises = this.symbols.map(async (symbol) => {
            try {
                prices[symbol] = await this.api.getCurrentPrice(symbol);
            } catch (error) {
                console.error(`Error getting ${symbol} price:`, error);
            }
        });
        await Promise.all(promises);
        return prices;
    }
}
